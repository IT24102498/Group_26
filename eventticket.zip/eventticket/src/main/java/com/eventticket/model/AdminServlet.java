package com.eventticket.model;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class AdminServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String action = request.getParameter("action");
        String id = request.getParameter("id");

        List<Booking> bookings = FileUtil.readBookings();

        if ("delete".equals(action)) {
            bookings.removeIf(b -> b.getId().equals(id));
        } else if ("update".equals(action)) {
            for (Booking b : bookings) {
                if (b.getId().equals(id)) {
                    b.setName(request.getParameter("name"));
                    b.setSeat(request.getParameter("seat"));
                    break;
                }
            }
        }

        FileUtil.writeBookings(bookings);
        response.sendRedirect("admin.html");
    }
}
