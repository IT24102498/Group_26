package com.eventticket.model;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {
    private static final String FILE_PATH = "C:\\Users\\USER\\Downloads\\eventticketv2.4 (3)\\eventticketv2.4 (2)\\eventticket\\src\\booking.txt";

    public static List<Booking> readBookings() throws IOException {
        List<Booking> bookings = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    bookings.add(new Booking(parts[0], parts[1], parts[2]));
                }
            }
        }
        return bookings;
    }

    public static void writeBookings(List<Booking> bookings) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Booking b : bookings) {
                writer.write(String.join(",", b.getId(), b.getName(), b.getSeat()));
                writer.newLine();
            }
        }
    }
}