package com.eventticket.model;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.UUID;

public class BookingServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        List<Booking> bookings = FileUtil.readBookings();
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        out.print("[");
        for (int i = 0; i < bookings.size(); i++) {
            Booking b = bookings.get(i);
            out.print("{\"id\":\"" + b.getId() + "\",\"name\":\"" + b.getName() + "\",\"seat\":\"" + b.getSeat() +  "\"}");
            if (i < bookings.size() - 1) out.print(",");
        }
        out.print("]");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String id = UUID.randomUUID().toString();
        String name = request.getParameter("name");
        String seat = request.getParameter("seat");

        List<Booking> bookings = FileUtil.readBookings();
        bookings.add(new Booking(id, name, seat));
        FileUtil.writeBookings(bookings);

        response.sendRedirect("index.html");
    }
}