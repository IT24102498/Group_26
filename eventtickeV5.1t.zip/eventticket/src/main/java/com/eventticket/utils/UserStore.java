package com.eventticket.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class UserStore {
    public static Map<String, String> users = new HashMap<>();
    public static Map<String, Customer> customers;

    static {
        // Preload with a sample user (username: admin, password: admin)
        users.put("admin", hashPassword("admin"));
        users.put("user", hashPassword("user123")); // Another example user
    }

    // Utility method to hash passwords using SHA-256
    private static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not found.", e);
        }
    }

    public static void addCustomer(Customer newCustomer) {
    }

    public static void deleteCustomer(String deleteId) {
    }

    public static void updateCustomer(Customer updatedCustomer) {
    }
}
