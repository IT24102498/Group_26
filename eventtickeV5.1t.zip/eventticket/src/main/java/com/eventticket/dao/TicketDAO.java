package com.eventticket.dao;

import com.eventticket.model.Ticket;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class TicketDAO {
    private static final String TICKET_FILE = "tickets.txt";

    // Save ticket purchase to text file
    public boolean saveTicket(Ticket ticket) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TICKET_FILE, true))) {
            // Format: eventId,eventName,price,date,location,quantity,userEmail
            String ticketData = String.format("%d,%s,%.2f,%s,%s,%d,%s",
                    ticket.getEventId(),
                    ticket.getEventName(),
                    ticket.getPrice(),
                    ticket.getDate(),
                    ticket.getLocation(),
                    ticket.getQuantity(),
                    ticket.getUserEmail());
            writer.write(ticketData);
            writer.newLine();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Optional: Read ticket data (for verification or debugging)
    public String readTickets() {
        StringBuilder tickets = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(TICKET_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                tickets.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tickets.toString();
    }
}