package com.eventticket.servlet;

import com.eventticket.model.Ticket;
import com.eventticket.dao.TicketDAO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/TicketServlet")
public class TicketServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        int eventId = Integer.parseInt(request.getParameter("eventId"));
        String eventName = request.getParameter("eventName");
        double price = Double.parseDouble(request.getParameter("price"));
        String date = request.getParameter("date");
        String location = request.getParameter("location");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        String userEmail = request.getParameter("userEmail");

        // Create Ticket object
        Ticket ticket = new Ticket(eventId, eventName, price, date, location, quantity, userEmail);

        // Save ticket using TicketDAO
        TicketDAO ticketDAO = new TicketDAO();
        boolean success = ticketDAO.saveTicket(ticket);

        // Redirect based on success
        if (success) {
            response.sendRedirect("confirmation.jsp"); // Assume a confirmation page exists
        } else {
            response.sendRedirect("error.jsp"); // Assume an error page exists
        }
    }
}