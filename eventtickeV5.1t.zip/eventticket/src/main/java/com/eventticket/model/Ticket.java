package com.eventticket.model;

public class Ticket {
    private int eventId;
    private String eventName;
    private double price;
    private String date;
    private String location;
    private int quantity;
    private String userEmail;

    // Constructor
    public Ticket() {}

    public Ticket(int eventId, String eventName, double price, String date, String location, int quantity, String userEmail) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.price = price;
        this.date = date;
        this.location = location;
        this.quantity = quantity;
        this.userEmail = userEmail;
    }

    // Getters and Setters
    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}